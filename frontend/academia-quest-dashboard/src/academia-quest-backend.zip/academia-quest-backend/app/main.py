"""
Academia Quest — FastAPI Backend
"""

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import Optional

from .database import get_db, engine
from . import models, schemas, crud
from .auth import (
    verify_google_token,
    create_jwt,
    get_current_user,
    get_current_user_optional,
)

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Academia Quest API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # lock down to your Vercel URL after hackathon
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Health ────────────────────────────────────────────────────────────────

@app.get("/")
def health():
    return {"status": "ok", "service": "academia-quest"}


# ─── Auth ──────────────────────────────────────────────────────────────────

@app.post("/api/auth/google", response_model=schemas.GoogleAuthResponse)
async def google_auth(payload: schemas.GoogleAuthRequest, db: Session = Depends(get_db)):
    """
    Frontend sends Google ID token → we verify it → return our JWT.
    The user copies the JWT into the extension once.
    """
    google_data = await verify_google_token(payload.idToken)

    user_id = google_data["sub"]          # unique Google user ID
    email = google_data["email"]
    name = google_data.get("name")
    picture = google_data.get("picture")

    # Upsert user
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if user:
        user.name = name
        user.picture = picture
    else:
        user = models.User(id=user_id, email=email, name=name, picture=picture)
        db.add(user)
    db.commit()

    token = create_jwt(user_id, email)
    return schemas.GoogleAuthResponse(
        token=token,
        userId=user_id,
        email=email,
        name=name,
        picture=picture,
    )


# ─── User ──────────────────────────────────────────────────────────────────

@app.get("/api/me")
def get_me(current_user: models.User = Depends(get_current_user)):
    return {
        "id": current_user.id,
        "email": current_user.email,
        "name": current_user.name,
        "picture": current_user.picture,
        "xp": current_user.xp,
        "level": current_user.level,
        "streak": current_user.streak,
    }


# ─── Assignments ───────────────────────────────────────────────────────────

@app.post("/api/assignments/sync")
def sync_assignments(
    payload: schemas.AssignmentSyncPayload,
    db: Session = Depends(get_db),
    current_user: Optional[models.User] = Depends(get_current_user_optional),
):
    user_id = current_user.id if current_user else None
    upserted = crud.upsert_assignments(db, payload.assignments, user_id=user_id)
    return {"ok": True, "upserted": upserted}


@app.post("/api/assignments/complete")
def complete_assignment(
    payload: schemas.CompletePayload,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    assignment = crud.mark_complete(db, payload.assignmentId, user_id=current_user.id)
    if not assignment:
        raise HTTPException(status_code=404, detail="Assignment not found")
    return {"ok": True}


@app.get("/api/assignments")
def get_assignments(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return crud.get_assignments(db, user_id=current_user.id)


# ─── Grades ────────────────────────────────────────────────────────────────

@app.post("/api/grades/sync")
def sync_grades(
    payload: schemas.GradeSyncPayload,
    db: Session = Depends(get_db),
    current_user: Optional[models.User] = Depends(get_current_user_optional),
):
    user_id = current_user.id if current_user else None
    upserted = crud.upsert_grades(db, payload.grades, user_id=user_id)
    return {"ok": True, "upserted": upserted}


@app.get("/api/grades")
def get_grades(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    return crud.get_grades(db, user_id=current_user.id)


# ─── Full sync (periodic alarm) ────────────────────────────────────────────

@app.post("/api/sync")
def full_sync(
    payload: schemas.FullSyncPayload,
    db: Session = Depends(get_db),
    current_user: Optional[models.User] = Depends(get_current_user_optional),
):
    user_id = current_user.id if current_user else payload.userId
    if payload.assignments:
        crud.upsert_assignments(db, payload.assignments, user_id=user_id)
    if payload.grades:
        crud.upsert_grades(db, payload.grades, user_id=user_id)
    if payload.state and current_user:
        crud.update_user_state(db, current_user, payload.state)
    return {"ok": True}
