# Academia Quest — Deployment Guide
# Where every file goes, what it fixes, and what's next

## FILE PLACEMENT MAP
────────────────────────────────────────────────────────────────

### FRONTEND  (gdghacks3/frontend/academia-quest-dashboard/)

  src/lib/api.ts
    → REPLACE  src/lib/api.ts
    → Fixes: trailing slash bug, adds OutlineUpload + game API calls

  src/hooks/useAuth.tsx
    → REPLACE  src/hooks/useAuth.tsx
    → Fixes: cleaner error handling on auth failure

  src/components/GoogleSignInButton.tsx
    → REPLACE  src/components/GoogleSignInButton.tsx
    → FIXES THE LOGIN BUG: waits for Google GSI script to load before
      rendering the button (was silently failing before)

  src/components/OutlineUpload.tsx
    → NEW FILE — drop into  src/components/OutlineUpload.tsx
    → Adds "📋 Upload outline" button next to the sync pill.
      Paste JSON course data → it syncs to the backend → calendar updates live.

  src/components/GameModal.tsx
    → REPLACE  src/components/GameModal.tsx
    → Game-ready shell. When your game component is done, import it and
      replace <GamePlaceholder /> with <BossRaid /> (instructions inside the file)

  src/App.tsx
    → REPLACE  src/App.tsx
    → Fixes: account popup dark mode (portal now gets data-theme attribute)
    → Adds: OutlineUpload button in the page header

────────────────────────────────────────────────────────────────

### BACKEND  (academia-quest-backend/)

  app/main.py
    → REPLACE  app/main.py
    → Adds: /api/game/start, /api/game/action, /api/game/state/:id
    → Also: completing an assignment now awards XP (100 pts)

  app/schemas.py
    → REPLACE  app/schemas.py
    → Adds: GameActionPayload (needed by the new game endpoints)

  All other backend files (auth.py, crud.py, models.py, database.py,
  requirements.txt, Dockerfile, deploy.sh) are UNCHANGED.

────────────────────────────────────────────────────────────────

### EXTENSION  (gdghacks3/extension/academia-quest-extension/)

  background.js  — ONE LINE EDIT (do not replace the whole file):
    Find:    API_BASE: "http://localhost:8000",
    Replace: API_BASE: "https://academia-quest-backend-153790104993.us-central1.run.app",

────────────────────────────────────────────────────────────────


## THINGS TO DO THAT WILL IMPROVE THE PROJECT

1. GOOGLE OAUTH CONSOLE (required for login to work on your deployed URL)
   → Go to https://console.cloud.google.com → APIs & Services → Credentials
   → Click your OAuth client (ID ending in .apps.googleusercontent.com)
   → Under "Authorized JavaScript origins" ADD your Vercel frontend URL
     e.g.  https://your-app.vercel.app
   → Without this, the Google button renders but clicking does nothing

2. BACKEND DATABASE_URL (required for Cloud Run deployment)
   → In Cloud Run → Edit & Deploy New Revision → Variables & Secrets
   → Add:  DATABASE_URL = postgresql://user:pass@host/dbname
   → Without this it uses SQLite (works locally, resets on every deploy)

3. FRONTEND .env.local — double-check these two values are correct:
     VITE_API_URL=https://academia-quest-backend-153790104993.us-central1.run.app
     VITE_GOOGLE_CLIENT_ID=153790104993-htfndv32dn52dg956lhj92ugbdsi6v6s.apps.googleusercontent.com
   (The client ID must end in .apps.googleusercontent.com — NOT the client secret)

4. DEPLOY FRONTEND
   → cd gdghacks3/frontend/academia-quest-dashboard
   → npm install && npm run build
   → Deploy the dist/ folder to Vercel (or run: npx vercel --prod)

5. DEPLOY BACKEND
   → cd academia-quest-backend
   → bash deploy.sh   (or docker build + gcloud run deploy)

6. OUTLINE UPLOAD JSON FORMAT
   Paste this shape into the Upload Outline dialog:
   [
     { "course": "CIS*3760", "title": "Assignment 1", "dueDate": "2026-02-14", "priority": 10 },
     { "course": "CIS*3760", "title": "Midterm",      "dueDate": "2026-03-05", "priority": 30 },
     { "course": "MATH*2170","title": "Problem Set 3", "dueDate": "2026-02-21", "priority": 15 }
   ]
   Fields: course (required), title (required), dueDate (ISO yyyy-mm-dd),
           priority (grade weight %), courseId (optional)

7. WIRING IN YOUR GAME COMPONENT (when it's ready)
   In GameModal.tsx:
     a) Import your component:
          import { BossRaid } from './BossRaid';
     b) Replace <GamePlaceholder /> with:
          <BossRaid user={user} />
     c) The backend game API is ready at:
          POST /api/game/start
          POST /api/game/action  { sessionId, action: "attack"|"defend"|"skill" }
          GET  /api/game/state/:sessionId
        And the frontend helpers are in src/lib/api.ts:
          api.gameStart()
          api.gameAction(sessionId, action)
          api.gameState(sessionId)
