// ─── PATCH: update API_BASE in background.js ─────────────────────────────────
//
// In:  gdghacks3/extension/academia-quest-extension/background.js
//
// Find this block near the top (around line 18):
//
//   const CONFIG = {
//     API_BASE: "http://localhost:8000",
//
// Replace with:
//
//   const CONFIG = {
//     API_BASE: "https://academia-quest-backend-153790104993.us-central1.run.app",
//
// That's the only change needed in background.js.
// ─────────────────────────────────────────────────────────────────────────────
//
// This file is just instructions — make the edit directly in background.js.
