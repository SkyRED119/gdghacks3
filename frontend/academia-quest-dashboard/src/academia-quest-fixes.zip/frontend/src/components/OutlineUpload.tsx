/**
 * OutlineUpload.tsx
 *
 * Lets a user paste a JSON course outline (or use the template) and sync it
 * to the backend as assignments.  The parent re-fetches after success so the
 * calendar updates immediately.
 *
 * Expected JSON shape (array):
 * [
 *   {
 *     "course": "CIS*3760",
 *     "title": "Assignment 1",
 *     "dueDate": "2026-02-14",
 *     "priority": 10
 *   },
 *   ...
 * ]
 *
 * Usage in App.tsx:
 *   import { OutlineUpload } from './components/OutlineUpload';
 *   ...
 *   <OutlineUpload onSynced={fetchData} />
 */

import { useState } from "react";
import { api } from "../lib/api";
import type { OutlineAssignment } from "../lib/api";

const TEMPLATE = JSON.stringify(
  [
    {
      course: "CIS*3760",
      title: "Assignment 1",
      dueDate: "2026-02-14",
      priority: 10,
    },
    {
      course: "CIS*3760",
      title: "Midterm Exam",
      dueDate: "2026-03-05",
      priority: 30,
    },
    {
      course: "MATH*2170",
      title: "Problem Set 3",
      dueDate: "2026-02-21",
      priority: 15,
    },
  ],
  null,
  2
);

interface Props {
  onSynced?: () => void;
}

export function OutlineUpload({ onSynced }: Props) {
  const [open, setOpen] = useState(false);
  const [raw, setRaw] = useState(TEMPLATE);
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSync() {
    setStatus("loading");
    setError("");
    let parsed: any[];
    try {
      parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) throw new Error("Must be a JSON array");
    } catch (e: any) {
      setStatus("error");
      setError("Invalid JSON: " + e.message);
      return;
    }

    // Normalise into the shape the backend expects
    const assignments: OutlineAssignment[] = parsed.map((item, i) => ({
      id: `outline-${item.course ?? "course"}-${i}-${Date.now()}`,
      course: item.course ?? item.courseName ?? "Unknown",
      courseId: item.courseId ?? item.course ?? `course-${i}`,
      title: item.title ?? item.name ?? `Item ${i + 1}`,
      dueDate: item.dueDate ?? item.due_date ?? undefined,
      priority:
        typeof item.priority === "number"
          ? item.priority
          : typeof item.weight === "number"
          ? item.weight
          : 0,
      status: "pending",
      source: "outline",
    }));

    try {
      await api.uploadOutline(assignments);
      setStatus("ok");
      onSynced?.();
      setTimeout(() => {
        setStatus("idle");
        setOpen(false);
      }, 1400);
    } catch (e: any) {
      setStatus("error");
      setError(e.message);
    }
  }

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        style={{
          background: "none",
          border: "1px solid var(--border)",
          borderRadius: 7,
          padding: "5px 12px",
          fontSize: 12,
          color: "var(--text-muted)",
          cursor: "pointer",
          fontFamily: "var(--font-body)",
          letterSpacing: "0.04em",
          transition: "background 0.15s, color 0.15s",
        }}
        onMouseOver={(e) =>
          ((e.currentTarget as HTMLButtonElement).style.background =
            "var(--bg-surface)")
        }
        onMouseOut={(e) =>
          ((e.currentTarget as HTMLButtonElement).style.background = "none")
        }
      >
        📋 Upload outline
      </button>
    );
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.45)",
        backdropFilter: "blur(5px)",
        zIndex: 400,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
      onClick={() => setOpen(false)}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "var(--bg-card)",
          border: "1px solid var(--border)",
          borderRadius: 14,
          padding: 28,
          width: "100%",
          maxWidth: 560,
          display: "flex",
          flexDirection: "column",
          gap: 16,
          boxShadow: "var(--shadow-lg)",
        }}
      >
        {/* Header */}
        <div
          style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}
        >
          <span
            style={{
              fontFamily: "var(--font-display)",
              fontSize: 20,
              fontStyle: "italic",
              color: "var(--text)",
            }}
          >
            Upload Course Outline
          </span>
          <button
            onClick={() => setOpen(false)}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "var(--text-muted)",
              fontSize: 16,
            }}
          >
            ✕
          </button>
        </div>

        {/* Instructions */}
        <p style={{ fontSize: 12, color: "var(--text-muted)", lineHeight: 1.6 }}>
          Paste your course outline as JSON. Each item needs at least{" "}
          <code
            style={{
              background: "var(--bg-surface)",
              padding: "1px 5px",
              borderRadius: 4,
              fontSize: 11,
            }}
          >
            course
          </code>
          ,{" "}
          <code
            style={{
              background: "var(--bg-surface)",
              padding: "1px 5px",
              borderRadius: 4,
              fontSize: 11,
            }}
          >
            title
          </code>
          , and{" "}
          <code
            style={{
              background: "var(--bg-surface)",
              padding: "1px 5px",
              borderRadius: 4,
              fontSize: 11,
            }}
          >
            dueDate
          </code>
          . Optional:{" "}
          <code
            style={{
              background: "var(--bg-surface)",
              padding: "1px 5px",
              borderRadius: 4,
              fontSize: 11,
            }}
          >
            priority
          </code>{" "}
          (grade weight %).
        </p>

        {/* Textarea */}
        <textarea
          value={raw}
          onChange={(e) => setRaw(e.target.value)}
          rows={14}
          spellCheck={false}
          style={{
            background: "var(--bg-surface)",
            border: "1px solid var(--border)",
            borderRadius: 8,
            padding: "10px 12px",
            fontFamily: "ui-monospace, monospace",
            fontSize: 12,
            color: "var(--text)",
            resize: "vertical",
            outline: "none",
            lineHeight: 1.55,
          }}
        />

        {/* Error */}
        {status === "error" && (
          <p style={{ fontSize: 12, color: "#c0392b" }}>{error}</p>
        )}

        {/* Actions */}
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end" }}>
          <button
            onClick={() => setRaw(TEMPLATE)}
            style={{
              background: "none",
              border: "1px solid var(--border)",
              borderRadius: 7,
              padding: "8px 14px",
              fontSize: 12,
              color: "var(--text-muted)",
              cursor: "pointer",
              fontFamily: "var(--font-body)",
            }}
          >
            Reset to template
          </button>
          <button
            onClick={handleSync}
            disabled={status === "loading"}
            style={{
              background: status === "ok" ? "#27ae60" : "var(--text)",
              color: status === "ok" ? "#fff" : "var(--bg)",
              border: "none",
              borderRadius: 7,
              padding: "8px 20px",
              fontSize: 13,
              fontWeight: 500,
              cursor: status === "loading" ? "not-allowed" : "pointer",
              fontFamily: "var(--font-body)",
              opacity: status === "loading" ? 0.6 : 1,
              transition: "background 0.2s",
            }}
          >
            {status === "loading"
              ? "Syncing…"
              : status === "ok"
              ? "✓ Synced!"
              : "Sync to dashboard"}
          </button>
        </div>
      </div>
    </div>
  );
}
